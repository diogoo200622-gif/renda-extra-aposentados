"use client"

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

const faqs = [
  {
    question: "O eBook promete dinheiro garantido?",
    answer:
      "Não. Nenhum material sério pode garantir ganhos financeiros. O que oferecemos são ideias práticas e seguras, testadas por pessoas reais. O resultado depende da sua dedicação.",
  },
  {
    question: "Preciso investir dinheiro para começar?",
    answer:
      "A maioria das ideias do guia pode ser colocada em prática sem nenhum investimento inicial, ou com investimento muito baixo. Tudo é explicado de forma clara.",
  },
  {
    question: "É difícil de usar ou entender?",
    answer:
      "Não. O eBook foi escrito em linguagem simples, com letras grandes e explicações passo a passo. Foi pensado para ser acessível a todos, independente da experiência com tecnologia.",
  },
  {
    question: "Funciona para qualquer aposentado?",
    answer:
      "Sim. O guia traz opções variadas, tanto online quanto offline, que se adaptam a diferentes perfis, rotinas e habilidades.",
  },
  {
    question: "Como recebo o eBook?",
    answer:
      "Após o pagamento, você recebe o acesso imediato por e-mail. O eBook é um arquivo PDF que pode ser lido no celular, tablet ou computador.",
  },
]

export function FaqSection() {
  return (
    <section className="bg-background py-16 md:py-24">
      <div className="mx-auto max-w-3xl px-5 md:px-8">
        <h2 className="text-center font-serif text-2xl font-bold text-foreground md:text-3xl lg:text-4xl">
          Perguntas frequentes
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-center text-lg text-muted-foreground">
          Tire suas dúvidas antes de comprar.
        </p>
        <Accordion type="single" collapsible className="mt-10">
          {faqs.map((faq, i) => (
            <AccordionItem key={i} value={`item-${i}`}>
              <AccordionTrigger className="text-left text-lg font-medium text-foreground">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-base leading-relaxed text-muted-foreground">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  )
}
